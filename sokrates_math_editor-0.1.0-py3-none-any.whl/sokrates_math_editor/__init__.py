from __future__ import annotations

from pathlib import Path
import streamlit.components.v1 as components

_FRONTEND = Path(__file__).parent / "frontend" / "dist"
_component = components.declare_component(
    "sokrates_math_editor",
    path=str(_FRONTEND),
)

def math_editor(
    *,
    value: str = "",
    placeholder: str = "",
    reset_token: int = 0,
    disabled: bool = False,
    key: str | None = None,
) -> dict:
    result = _component(
        value=value,
        placeholder=placeholder,
        reset_token=reset_token,
        disabled=disabled,
        key=key,
        default={"value": value, "sequence": 0},
    )
    return result or {"value": value, "sequence": 0}
